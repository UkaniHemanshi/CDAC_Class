# -*- coding: utf-8 -*-


import pandas as pd

df=pd.read_csv("D:\\advanced analytics\RHS-2019-SC-PHC_CHC.csv")
print(df)

print(df.head(5))

print(df.tail(5))

print(df.columns)

print(len(df))
